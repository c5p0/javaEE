package cn.itcast.springmvc.service;

import java.util.List;

import com.itheima.springmvc.pojo.Items;

public interface ItemService {
	public List<Items> selectItemList();
}
