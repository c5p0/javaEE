package cn.itcast.springmvc.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import cn.itcast.springmvc.service.ItemService;

import com.itheima.springmvc.pojo.Items;

@Controller
public class ItemController {
	
	@Autowired
	private ItemService service;
	@RequestMapping(value="/item/itemlist.action")
	public ModelAndView itemList()
	{
		List<Items> list = service.selectItemList();
		ModelAndView mav = new ModelAndView();
		mav.addObject("itemList", list);
		mav.setViewName("itemList");
		return mav;
	}
}
